function setup() {
  createCanvas(1000,700);
	img = loadImage("https://static.miraheze.org/thefinalrumblewiki/2/2f/Funnyv.jpg")
}
var s = "Valentine 2020";
var v = "The True President";

var value = 0;
var q = 255;
function draw() {
	background(value);
	textSize(78);
	fill(q);
text(s, 240, 85)
	 image(img, 240, 110);
	fill(q);
text(v, 160, 620)
}
function mouseClicked() {
  if (value == 255) {
    value = 0;
		q = 255;
  } else {
    value = 255;
		q = 0;
  }
}