var value = 255;
var value1 = 255;
var value2 = 255;
var value3 = 255;
var value4 = 255;
var value5 = 255;
var value6 = 0;
var value7 = 0;
function draw() {
 fill(value);
 rect(-1, -1, 300, 300);
 fill(value1);
 ellipse(20, 30, 15, 15);
 fill(137, 0, 0);
 arc(51, 60, 50, 50, 0, PI, CHORD);
 fill(value2);
 ellipse(80, 30, 15, 15);
 fill(value6);
 ellipse(20, 30, 5, 5);
 fill(value7);
 ellipse(80, 30, 5, 5);
 fill(value4);
 rect(36, 60, 30, 10);
 fill(value5);
 rect(-1, -1, 1, 1);
}
 
function mouseClicked() {
 if (value1 == 255) {
   value1 = 0;
 } else {
   value1 = 255;
 }
}
