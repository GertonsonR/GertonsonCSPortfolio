var startX = int(random(480));
var startY = 0;
var endX = 150;
var endY = 0;
function setup() {
  createCanvas(480, 500);
	background(0);
	strokeWeight(2);
}

function draw() {
	stroke(255);
	while (endY < 500) {
		endY = startY + int(random(10));
		endX = startX + int(random(-9, 9));
		line(startX, startY, endX, endY);
		startX = endX;
		startY = endY;
  }
}
function mousePressed() {
	startX = int(random(480));
	startY = 0;
	endX = 150;
	endY = 0;
}