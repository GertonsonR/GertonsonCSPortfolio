var orb = [];
function setup() {
  createCanvas(600, 600);
  for (var i=0; i<100; i++) {
    orb[i] = new Orb(width/2, height/2);
  }
}
function draw() {
  background(50, 210, 160);
  textSize(32);
  fill(0, 102, 153);
  text("They follow your mouse!", 10, 30); 
  for (var i=0; i<orb.length; i++) {
    orb[i].show();
    orb[i].move();
  }
}

class Orb {
  constructor(xaxis, yaxis) {
    this.x = xaxis;
    this.y = yaxis;
    this.red = (int)(Math.random()*256);
    this.green = (int)(Math.random()*256);
    this.blue = (int)(Math.random()*256);
  }
 move() {
    this.x+=(int)(Math.random()*5)-2;
    this.y+=(int)(Math.random()*5)-2;
    if(mouseX>this.x) {
      this.x+=(int)(Math.random()*20);
    }else if(mouseX<this.x) {
     this.x-=(int)(Math.random()*20); 
    }
   if(mouseY>this.y) {
      this.y+=(int)(Math.random()*20);
    }else if(mouseY<this.y) {
     this.y-=(int)(Math.random()*20); 
    }
  }
  show() {
    fill(this.red, this.green, this.blue);
    ellipse(this.x, this.y, 10, 10);
  }
}
