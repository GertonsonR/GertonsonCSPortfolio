class Die
{
  roll()
  {
    textSize(25);
    text("Click to roll the dice!", 127, 35);
    var die1 = int(random(1, 7));
    var die2 = int(random(1, 7));
    var die3 = int(random(1, 7));
    var die4 = int(random(1, 7));
    var die5 = int(random(1, 7));
    var die6 = int(random(1, 7));
    var die7 = int(random(1, 7));
    var die8 = int(random(1, 7));
    var die9 = int(random(1, 7));
    textSize(45);
    fill(0, 0, 0);
    text(die1,  107, 127);
    fill(0, 0, 0);
    text(die2,  107, 262);
    fill(0, 0, 0);
    text(die3,  107, 397);
    fill(0, 0, 0);
    text(die4,  242, 127);
    fill(0, 0, 0);
    text(die5,  242, 262);
    fill(0, 0, 0);
    text(die6,  242, 397);
    fill(0, 0, 0);
    text(die7,  377, 127);
    fill(0, 0, 0);
    text(die8,  377, 262);
    fill(0, 0, 0);
    text(die9,  377, 397);
    fill(188, 81, 0);
    textSize(25);
    text("Your rolls multiply to be " + die1*die2*die3*die4*die5*die6*die7*die8*die9, 65, 480);
  }
	
  show()
  {
    fill(255, 255, 255);
    rect(80, 70, 80, 80, 20);
    fill(255, 255, 255);
    rect(80, 205, 80, 80, 20);
    fill(255, 255, 255);
    rect(80, 340, 80, 80, 20);
    fill(255, 255, 255);
    rect(215, 70, 80, 80, 20);
    fill(255, 255, 255);
    rect(215, 205, 80, 80, 20);
    fill(255, 255, 255);
    rect(215, 340, 80, 80, 20);
    fill(255, 255, 255);
    rect(350, 70, 80, 80, 20);
    fill(255, 255, 255);
    rect(350, 205, 80, 80, 20);
    fill(255, 255, 255);
    rect(350, 340, 80, 80, 20);
    
  }
}

dice = new Die (100,100);

function setup() {
  createCanvas(500, 500);
  noLoop();
}
function draw() {
  background(0, 3, 101);
  dice.show();
  dice.roll();
  
}
function mousePressed()
{
  redraw();
}